import json
import tweepy
import requests

def lambda_handler(event, context):
    CONSUMER_KEY = "TVsVwwwRWNlshoujsg93al1tL"
    CONSUMER_SECRET = "qCnlCVYJowOebNzAogbK0hDtWPSaX47IrniuOw2MQnKWV7j089" 
        
    ACCESS_TOKEN = "1490945644026298368-2U339VeE31YzqP1eTcwuTxwB5cyeJR"  
    ACCESS_TOKEN_SECRET = "8L27TwB6lpPGbsuNG6mCK1cZSnQ7dKQnoX8qsIg5oFlf4" 
        
    auth = tweepy.OAuthHandler(CONSUMER_KEY, CONSUMER_SECRET)
    auth.set_access_token(ACCESS_TOKEN, ACCESS_TOKEN_SECRET)
    twitter = tweepy.API(auth)
    
    URL = "https://zenquotes.io/api/today"
    response = requests.get(URL)
    if response.status_code == 200:
        data = response.json()
        tweet = data[0]['q'] + " - " +data[0]['a']
    post_tweet = twitter.update_status(tweet) 


    return {
        'body': json.dumps('tweet sent')
    }
